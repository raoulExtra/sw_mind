import { AsyncQueue } from '../../AsyncQueue';
import { CommitAgent, CommitResult } from '../../CommitAgent';
import { createWriteIntent } from '../../WriteIntent';
import Database from 'better-sqlite3';

describe('Write Queue Integration', () => {
  describe('End-to-end write flow', () => {
    it('should process multiple agents writes in order', async () => {
      const db = new Database(':memory:');
      db.exec('CREATE TABLE events (id INTEGER PRIMARY KEY, agent TEXT, data TEXT)');
      
      const queue = new AsyncQueue<{ sql: string; params: any[] }>();
      const agent = new CommitAgent(db);
      const results: CommitResult[] = [];
      agent.onLog((r) => results.push(r));
      
      const submitCount = 5;
      for (let i = 0; i < submitCount; i++) {
        agent.submit(createWriteIntent(
          'INSERT INTO events (agent, data) VALUES (?, ?)',
          ['agent-1', `event-${i}`]
        ));
      }
      
      await agent.drain();
      
      const rows = db.prepare('SELECT agent, data FROM events ORDER BY id').all() as { agent: string; data: string }[];
      expect(rows).toHaveLength(submitCount);
      expect(rows.every(r => r.agent === 'agent-1')).toBe(true);
      
      agent.close();
      db.close();
    });

    it('should integrate AsyncQueue with CommitAgent', async () => {
      const db = new Database(':memory:');
      db.exec('CREATE TABLE items (id INTEGER PRIMARY KEY, value TEXT)');
      
      const queue = new AsyncQueue<string>();
      const agent = new CommitAgent(db);
      
      const items = ['first', 'second', 'third'];
      items.forEach(item => queue.push(item));
      
      const processed: string[] = [];
      while (processed.length < items.length) {
        const item = await queue.pop();
        agent.submit(createWriteIntent('INSERT INTO items (value) VALUES (?)', [item]));
        await agent.drain();
        processed.push(item);
      }
      
      const rows = db.prepare('SELECT value FROM items ORDER BY id').all() as { value: string }[];
      expect(rows.map(r => r.value)).toEqual(items);
      
      agent.close();
      db.close();
    });
  });
});