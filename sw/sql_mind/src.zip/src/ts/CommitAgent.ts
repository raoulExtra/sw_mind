import Database from 'better-sqlite3';
import { WriteIntent } from './WriteIntent';
import { AsyncQueue } from './AsyncQueue';

export interface CommitResult {
  intentId: string;
  agentId: string;
  success: boolean;
  error?: string;
  timestamp: number;
}

export type LogCallback = (result: CommitResult) => void;

export class CommitAgent {
  private db: Database.Database;
  private queue: AsyncQueue<WriteIntent>;
  private logCallback?: LogCallback;
  private running = true;
  private drainResolvers: (() => void)[] = [];
  private processedCount = 0;
  private submittedCount = 0;

  constructor(db: Database.Database) {
    this.db = db;
    this.queue = new AsyncQueue<WriteIntent>();
    this.startLoop();
  }

  private startLoop(): void {
    (async () => {
      while (this.running) {
        const intent = await this.queue.pop();
        await this.process(intent);
        this.processedCount++;
        if (this.processedCount === this.submittedCount) {
          this.drainResolvers.forEach(resolve => resolve());
          this.drainResolvers = [];
        }
      }
    })();
  }

  onLog(callback: LogCallback): void {
    this.logCallback = callback;
  }

  async process(intent: WriteIntent): Promise<CommitResult> {
    const result: CommitResult = {
      intentId: intent.id,
      agentId: intent.agentId,
      success: false,
      timestamp: Date.now(),
    };

    try {
      this.db.exec('BEGIN');
      const stmt = this.db.prepare(intent.sql);
      stmt.run(intent.params ?? []);
      this.db.exec('COMMIT');
      result.success = true;
    } catch (error) {
      this.db.exec('ROLLBACK');
      result.error = error instanceof Error ? error.message : String(error);
    }

    this.logCallback?.(result);
    return result;
  }

  submit(intent: WriteIntent): void {
    this.submittedCount++;
    this.queue.push(intent);
  }

  async drain(): Promise<void> {
    return new Promise(resolve => {
      if (this.processedCount === this.submittedCount && this.submittedCount > 0) {
        resolve();
        return;
      }
      this.drainResolvers.push(resolve);
    });
  }

  close(): void {
    this.running = false;
  }
}