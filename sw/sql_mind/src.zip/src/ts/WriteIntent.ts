import { ulid } from 'ulid';

export interface WriteIntent {
  id: string;
  sql: string;
  params?: any[];
  agentId: string;
  timestamp: number;
}

export function createWriteIntent(
  sql: string,
  params?: any[],
  options?: { agentId?: string }
): WriteIntent {
  return {
    id: ulid(),
    sql,
    params,
    agentId: options?.agentId ?? 'default-agent',
    timestamp: Date.now(),
  };
}