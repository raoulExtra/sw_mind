import { AsyncQueue } from '../../AsyncQueue';

describe('AsyncQueue', () => {
  describe('FR-WRITEQ-01: Agents must send write requests to a centralized queue', () => {
    it('should push and pop items in FIFO order', async () => {
      const queue = new AsyncQueue<number>();
      
      queue.push(1);
      queue.push(2);
      queue.push(3);
      
      expect(await queue.pop()).toBe(1);
      expect(await queue.pop()).toBe(2);
      expect(await queue.pop()).toBe(3);
    });

    it('should handle async consumers waiting for items', async () => {
      const queue = new AsyncQueue<string>();
      
      const popPromise = queue.pop();
      
      setTimeout(() => {
        queue.push('first');
        queue.push('second');
      }, 10);
      
      expect(await popPromise).toBe('first');
      expect(await queue.pop()).toBe('second');
    });
  });

  describe('FR-WRITEQ-02: Queue must preserve write order', () => {
    it('should maintain FIFO ordering for multiple concurrent pushes', async () => {
      const queue = new AsyncQueue<number>();
      const items = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
      
      items.forEach(item => queue.push(item));
      
      for (const expected of items) {
        expect(await queue.pop()).toBe(expected);
      }
    });

    it('should resolve promises in push order', async () => {
      const queue = new AsyncQueue<number>();
      const results: number[] = [];
      
      queue.push(1);
      queue.push(2);
      queue.push(3);
      
      results.push(await queue.pop());
      results.push(await queue.pop());
      results.push(await queue.pop());
      
      expect(results).toEqual([1, 2, 3]);
    });
  });

  describe('FR-WRITEQ-03: Queue must handle backpressure', () => {
    it('should buffer items when no consumers are waiting', async () => {
      const queue = new AsyncQueue<number>();
      
      for (let i = 0; i < 100; i++) {
        queue.push(i);
      }
      
      for (let i = 0; i < 100; i++) {
        expect(await queue.pop()).toBe(i);
      }
    });

    it('should handle multiple producers and consumers', async () => {
      const queue = new AsyncQueue<number>();
      const producerResults: number[] = [];
      
      for (let i = 0; i < 5; i++) {
        queue.push(i);
        producerResults.push(i);
      }
      
      const consumerResults: number[] = [];
      for (let i = 0; i < 5; i++) {
        consumerResults.push(await queue.pop());
      }
      
      expect(consumerResults).toEqual(producerResults);
    });
  });
});