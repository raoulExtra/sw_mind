import { CommitAgent, CommitResult } from '../../CommitAgent';
import { WriteIntent, createWriteIntent } from '../../WriteIntent';
import Database from 'better-sqlite3';

describe('CommitAgent', () => {
  describe('FR-WRITEQ-08: Commit agent must process one intent at a time', () => {
    it('should process intents sequentially', async () => {
      const db = new Database(':memory:');
      db.exec('CREATE TABLE test (id INTEGER PRIMARY KEY, value TEXT)');
      
      const agent = new CommitAgent(db);
      const logs: CommitResult[] = [];
      agent.onLog((result: CommitResult) => logs.push(result));
      
      agent.submit(createWriteIntent('INSERT INTO test (value) VALUES (1)'));
      agent.submit(createWriteIntent('INSERT INTO test (value) VALUES (2)'));
      agent.submit(createWriteIntent('INSERT INTO test (value) VALUES (3)'));
      
      await agent.drain();
      
      const rows = db.prepare('SELECT value FROM test ORDER BY id').all() as { value: string }[];
      expect(rows.map(r => r.value)).toEqual(['1', '2', '3']);
      
      agent.close();
      db.close();
    });
  });

  describe('FR-WRITEQ-09: Each commit must be ACID-compliant', () => {
    it('should rollback on error', async () => {
      const db = new Database(':memory:');
      db.exec('CREATE TABLE test (id INTEGER PRIMARY KEY, value TEXT)');
      db.exec('CREATE TABLE other (id INTEGER PRIMARY KEY, value TEXT)');
      
      const agent = new CommitAgent(db);
      const logs: CommitResult[] = [];
      agent.onLog((result: CommitResult) => logs.push(result));
      
      agent.submit(createWriteIntent('INSERT INTO test (value) VALUES (1)'));
      agent.submit(createWriteIntent('INSERT INTO nonexistent (value) VALUES (2)'));
      agent.submit(createWriteIntent('INSERT INTO other (value) VALUES (3)'));
      
      await agent.drain();
      
      expect(logs[0].success).toBe(true);
      expect(logs[1].success).toBe(false);
      expect(logs[2].success).toBe(true);
      
      const otherRows = db.prepare('SELECT * FROM other').all();
      expect(otherRows).toHaveLength(1);
      
      agent.close();
      db.close();
    });
  });

  describe('FR-WRITEQ-10: Commit agent must log all operations', () => {
    it('should log success and failure', async () => {
      const db = new Database(':memory:');
      db.exec('CREATE TABLE test (id INTEGER PRIMARY KEY, value TEXT)');
      
      const agent = new CommitAgent(db);
      const logs: CommitResult[] = [];
      
      agent.onLog((result: CommitResult) => logs.push(result));
      
      agent.submit(createWriteIntent('INSERT INTO test (value) VALUES (1)'));
      agent.submit(createWriteIntent('INSERT INTO nonexistent (value) VALUES (2)'));
      
      await agent.drain();
      
      expect(logs).toHaveLength(2);
      expect(logs[0].success).toBe(true);
      expect(logs[1].success).toBe(false);
      
      agent.close();
      db.close();
    });
  });
});